﻿using System.ComponentModel.DataAnnotations;

namespace BugProject.Models
{
    public class Bug
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Title is required")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Description is required")]
        public string Description { get; set; }

        [Required(ErrorMessage = "Status is required")]
        public string Status { get; set; }

        public string UserId { get; set; }
        public virtual ApplicationUser User { get; set; }
    }

}
