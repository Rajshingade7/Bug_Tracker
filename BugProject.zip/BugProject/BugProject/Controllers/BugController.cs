﻿using BugProject.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;


namespace BugProject.Controllers
{
    [Authorize]
    public class BugController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public BugController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public async Task<ActionResult> Index()
        {
            var currentUserId = _userManager.GetUserId(User);
            var userBugs = await _context.Bugs
                .Where(b => b.UserId == currentUserId)
                .Include(b => b.User)
                .ToListAsync();
            return View(userBugs);
        }
        [Authorize]
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> Create(Bug bug)
        {
            if (!User.Identity.IsAuthenticated)
            {
                ModelState.AddModelError("", "You must be logged in to report a bug.");
                return View(bug);
            }

            bug.UserId = _userManager.GetUserId(User);

            _context.Bugs.Add(bug);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index");

        }
        public IActionResult Edit(int id)
        {
            var bug = _context.Bugs.FirstOrDefault(b => b.Id == id);
            if (bug == null)
            {
                return NotFound();
            }
            return View(bug);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Bug model)
        {
            model.UserId = _userManager.GetUserId(User);

            _context.Bugs.Update(model);
                _context.SaveChanges();
                return RedirectToAction("Index");
           
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var bug = await _context.Bugs.FindAsync(id);
            if (bug == null) return NotFound();

            _context.Bugs.Remove(bug);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
    }
}
